# -*- coding: utf-8 -*-
# collect.py
 
import xbmcplugin, xbmcgui, urllib, json,urlparse,sys
reload(sys)
sys.setdefaultencoding('utf-8')
host="192.168.31.250"
port="5100"
print 'BEGIN:'
handle=int(sys.argv[1])
params={}
if sys.argv[2]!='':
    params = dict(urlparse.parse_qsl(sys.argv[2].lstrip('?')))
act=params.get("type")
mypath=params.get("collectpath","")
fileroot=urllib.urlopen("http://"+host+":"+str(port)+"/getfilesroot")
dataroot=fileroot.read()
fileroot.close()
root=json.loads(dataroot)
print root
try:
    fileconfig=urllib.urlopen("http://"+host+":"+str(port)+"/homeconfig/homeconfig")
    configdata=fileconfig.read()
    fileconfig.close()
    config=json.loads(configdata)
except:
    config=[]
pubpath="/ipfs/QmcZL56G6jbNTpDr1eGbDeic5gXwHqAANNmAjkzHvwX8pq"
nopub=False
share=[]
if config:
    if 'PubData' in config.keys():
        pubpath=config["PubData"]
    share=config.get("Share")
    nopub=config.get("NoPub")
    

navdata=[]
items=[]
def getrootnav(host,port,root,navdata):
    if not root:
        return
    try:
        filenav=urllib.urlopen("http://"+host+":"+str(port)+"/ipfs/"+root+"/privcollect/navData")
        datanav=filenav.read()
        filenav.close()
        mynav=json.loads(datanav)
        print (mynav)
    except:
        mynav=[]
        print (mynav)

    if len(mynav)>0:
        for nav in mynav:      
            navdata.append({"title":"local"+nav["title"],"path":"/ipfs/"+root+"/privcollect/home"+nav["path"],"collectpath":"/ipfs/"+root+"/privcollect","type":"homelist"})
    return navdata
    
def getnav(host,port,path,name,navdata):    
    try:
        filenav=urllib.urlopen("http://"+host+":"+str(port)+path+"/navData")
        datanav=filenav.read()
        filenav.close()
        mynav=json.loads(datanav)
        print (mynav)
    except:
        mynav=[]
        print (mynav)

    if len(mynav)>0:
        for nav in mynav:      
            navdata.append({"title":name+nav["title"],"path":path+"/home"+nav["path"],"collectpath":path,"type":"homelist"})
    return navdata
    
def getfiles(host,port,path):
    try:
        file=urllib.urlopen("http://"+host+":"+str(port)+path)
        jsondata=file.read()
        file.close()
        data=json.loads(jsondata)
    except:
        data=None
    return data
def getdirlist(host,port,path):    
    try:
        file=urllib.urlopen("http://"+host+":"+str(port)+"/getdirlist?path="+path)
        jsondata=file.read()
        file.close()
        data=json.loads(jsondata)
    except:
        data=None    
    return data

def movielist(host,port,mypath,pubpath,listfiles,listtitle,items):
    if not listfiles:
        return items
    for files in listfiles:
        compilation=files.get("compilation")
        img=files.get("img")
        if img:
            image="http://"+host+":"+str(port)+"/ipfs/"+files.get("img")
        else:
            image=""
        if compilation:
            isFolder=True
            listitem = xbmcgui.ListItem(label=listtitle+files["title"], thumbnailImage=image)
            url=sys.argv[0]+'?'+"type=list"
            url +="&path="+mypath+"/compilation"+files.get("path","none")
            url +="&collectpath="+mypath
            items.append((url,listitem,isFolder))
        else:
            isFolder=True
            listitem = xbmcgui.ListItem(label=listtitle+files["title"], thumbnailImage=image)
            info={
            "genre":files.get("genre","").replace(" ","").split("/"),
            "country":files.get("region","").replace(" ","").split("/"),
            "year":int(files.get("year",0)),
            "rating":float(files.get("rating",0)),
            "title":files.get("title","")
            }
            listitem.setInfo('video', info)
            url=sys.argv[0]+'?'+"type=fileslist"
            if files.get("own"):
                url +="&path="+mypath+"/respool"+files.get("path","none")
            else:
                url +="&path="+pubpath+"/respool"+files.get("path","none")
            url +="&collectpath="+mypath
            items.append((url,listitem,isFolder))
    return items

def fileslist(host,port,mypath,pubpath,files,items):
    if not files:
        return items
    data=files.get("files")
    if not data:
        return items
    isFolder=False   
    tv=files.get("type")
    parentfiles=files.get("parentfiles")
    if tv=="tv":
        if parentfiles:
            parent=getfiles(host,port,pubpath+"/respool"+parentfiles)
            parentdata=parent.get("files")
            if parentdata:
                data.extend(parentdata)
        for copy in data:
            info={
            "genre":files.get("genre","").replace(" ","").split("/"),
            "country":files.get("region","").split("/"),
            "year":int(files.get("year",0)),
            "rating":float(files.get("rating",0)),
            "director":files.get("director",""),
            "cast":files.get("cast","").split("/"),
            "writer":files.get("writer","").split("/"),
            "sorttitle":files.get("title",""),
            "episodeguide":files.get("overview",""),
            "title": files.get("title",""),
            "title": copy.get("filename","")
            }
            listitem = xbmcgui.ListItem(label=str(copy.get("episode",0)), thumbnailImage="http://"+host+":"+str(port)+"/ipfs/"+files.get("img",""))            
            listitem.addStreamInfo('video', { 'codec': files.get("codec_name",""), 'width' : int(files.get("width",0)),"height":int(files.get("height",0)) })
            audio=files.get("audio")
            if audio:
                for a in audio:
                    listitem.addStreamInfo('audio', { 'codec': a.get("audioCodec_name","")+" "+a.get("channel_layout",""), 'language': a.get("language","")})
            subtitle=files.get("subtitle")
            if subtitle:
                for s in subtitle:
                   listitem.addStreamInfo('subtitle', { 'language': s.get("subtitlelanguage","")})
            listitem.setInfo(type='video', infoLabels=info)
            url="http://"+host+":"+str(port)+"/ipfs/"+copy.get("hash","")
            items.append((url,listitem,isFolder))
    else:
        if parentfiles:
            parent=getfiles(host,port,pubpath+"/respool"+parentfiles)
            parentdata=parent.get("files")
            if parentdata:
                data.extend(parentdata)
        for copy in data:
            info={
            "genre":files.get("genre","").replace(" ","").split("/"),
            "country":files.get("region","").split("/"),
            "year":int(files.get("year",0)),
            "rating":float(files.get("rating",0)),
            "director":files.get("director",""),
            "cast":files.get("cast","").split("/"),
            "writer":files.get("writer","").split("/"),
            "sorttitle":files.get("title",""),
            "episodeguide":files.get("overview",""),
            "title": files.get("title",""),
            "size":copy.get("size",0)
            }
            listitem = xbmcgui.ListItem(label=copy.get("filename",""), thumbnailImage="http://"+host+":"+str(port)+"/ipfs/"+files.get("img",""))
            listitem.addStreamInfo('video', { 'codec': copy.get("codec_name",""), 'width' : int(copy.get("width",0)),"height":int(copy.get("height",0)),"duration":int(float(copy.get("fileDuration","0")))})
            audio=copy.get("audio")
            if audio:
                for a in audio:
                    listitem.addStreamInfo('audio', { 'codec': a.get("audioCodec_name","")+" "+a.get("channel_layout",""), 'language': a.get("language","")})
            subtitle=copy.get("subtitle")
            if subtitle:
                for s in subtitle:
                   listitem.addStreamInfo('subtitle', { 'language': s.get("subtitlelanguage","")}) 
            listitem.setInfo(type='video', infoLabels=info)
            url="http://"+host+":"+str(port)+"/ipfs/"+copy.get("hash","")
            items.append((url,listitem,isFolder))
    return items


if sys.argv[2]=='':    
    navdata=getrootnav(host,port,root,navdata)
    if not nopub:
        navdata=getnav(host,port,pubpath,"pub",navdata)
    if share:
        try:
           shareurl=urllib.urlopen("http://"+host+":"+str(port)+pubpath+"/shareData")
           shareData=shareurl.read()
           shareurl.close()
           sharelists=json.loads(shareData)
        except:
            sharelists=[]
        listsdata=sharelists.get("Data")
        if listsdata:
            for myshare in share:
                for sharelist in listsdata:
                    if myshare["Cid"]==sharelist["Cid"]:
                        navdata=getnav(host,port,sharelist["Path"],sharelist["Name"],navdata)
                        break
    downlist=getfiles(host,port,"/homeconfig/pinfiles")
    if downlist:
        navdata.append({"title":"down","path":"","type":"down"})
    favoritesList=[]
    if config:
        favoritesList=config.get("FavoritesList")
    if favoritesList:
        for favorites in favoritesList:
            if listsdata:
                for sharelist in listsdata:
                    if sharelist["Cid"]==favorites:
                        navdata.append({"title":sharelist["Name"],"path":sharelist["Path"],"collectpath":sharelist["Path"],"type":"favorites"})
    for ndata in navdata:
        url=sys.argv[0]+'?'+"type="+ndata["type"]
        url +="&path="+ndata["path"]        
        url +="&collectpath="+ndata.get("collectpath","")
        listitem=xbmcgui.ListItem(ndata["title"])
        items.append((url,listitem,True))
elif act=="homelist":
    homelistpath=params.get("path")
    homefile=getfiles(host,port,homelistpath)
    privateValue=homefile.get("privateValue")
    homelists=homefile.get("list")
    if privateValue:
        isFolder=True
        listitem = xbmcgui.ListItem(label="所有集合")
        url=sys.argv[0]+'?'+"type=showall"
        url +="&path="+mypath+privateValue
        url +="&collectpath="+mypath
        url +="&privateValue="+privateValue
        items.append((url,listitem,isFolder))
    if homelists:
        for list in homelists:
            listtitle=list.get("title")
            listmodel=list.get("model")
            listfiles=list.get("files")
            if listmodel=="Homelist01" or listmodel=="Homelist02":
                if listfiles:
                    items=movielist(host,port,mypath,pubpath,listfiles,"home-",items)
            elif listmodel=="Homelist11":
                if listfiles:
                    for files in listfiles:
                        isFolder=True
                        listitem = xbmcgui.ListItem(label="Collection-"+files["title"])
                        url=sys.argv[0]+'?'+"type=list"
                        url +="&path="+mypath+"/compilation"+files.get("path")
                        url +="&collectpath="+mypath
                        items.insert(0,(url,listitem,isFolder))
            else:
                if listfiles:
                    items=movielist(host,port,mypath,pubpath,listfiles,listtitle+"-",items)
elif act=="showall":
    
    listpath=params.get("collectpath")+"/collect"+params.get("privateValue")
    listdata=getfiles(host,port,listpath)
    if not listdata:
        dir=params.get("path")
        dirlist=getdirlist(host,port,dir)
        if dirlist:
            for file in dirlist:
                indir=file.get("Type")
                filename=file.get("Name")
                if indir==1:                    
                    isFolder=True
                    listitem = xbmcgui.ListItem(label=filename)
                    url=sys.argv[0]+'?'+"type=showall"
                    url +="&path="+mypath+params.get("privateValue")+"/"+filename
                    url +="&collectpath="+mypath
                    url +="&privateValue="+params.get("privateValue")+"/"+filename
                    items.append((url,listitem,isFolder))
                else:
                    isFolder=True
                    listitem = xbmcgui.ListItem(label=filename)
                    url=sys.argv[0]+'?'+"type=fileslist"                 
                    url +="&path="+mypath+params.get("privateValue")+"/"+filename
                    url +="&collectpath="+mypath
                    items.append((url,listitem,isFolder))       
    else:
        items=movielist(host,port,mypath,pubpath,listdata,"",items)
elif act=="list":
    listpath=params.get("path")
    listdata=getfiles(host,port,listpath)
    items=movielist(host,port,mypath,pubpath,listdata,"",items)
elif act=="fileslist":
    filespath=params.get("path")
    filesdata=getfiles(host,port,filespath)
    items=fileslist(host,port,mypath,pubpath,filesdata,items)
elif act=="favorites":
    navdata=getnav(host,port,mypath,"",navdata)
    for ndata in navdata:
        url=sys.argv[0]+'?'+"type="+ndata["type"]
        url +="&path="+ndata["path"]        
        url +="&collectpath="+ndata.get("collectpath","")
        listitem=xbmcgui.ListItem(ndata["title"])
        items.append((url,listitem,True))
elif act=="down":
    downdata=getfiles(host,port,"/pinfiles")
    if downdata:
        for downfile in downdata:            
            downsize=downfile.get("Size")            
            if downsize and downsize>0:
                url="http://"+host+":"+str(port)+"/ipfs/"+downfile.get("Cid","")
                listitem=xbmcgui.ListItem(downfile.get("Name",""))
                items.append((url,listitem,False))

xbmcplugin.addDirectoryItems(handle,items,len(items))    
xbmcplugin.endOfDirectory(handle)
print 'END'